package com.example.evaluacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView tvcategoria, tvtransporte, tvtotal;
    EditText etcantidad;
    RadioButton jrbpremiun, jrbnormal, jrbeconomica;
    CheckBox cbtransporte;
    Button btcalcular, btcancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Esconder el titulo por defecto
        getSupportActionBar().hide();

        //Asociar objetos Java con objetos xml
        tvcategoria = findViewById(R.id.tvcategoria);
        tvtransporte = findViewById(R.id.tvtransporte);
        tvtotal = findViewById(R.id.tvtotal);
        etcantidad = findViewById(R.id.etcantidad);
        jrbpremiun= findViewById(R.id.rbpremiun);
        jrbnormal = findViewById(R.id.rbnormal);
        jrbeconomica = findViewById(R.id.rbeconomica);
        cbtransporte = findViewById(R.id.cbtransporte);
        btcalcular = findViewById(R.id.btnCalcular);
        btcancelar = findViewById(R.id.btcancelar);
    }

    public void Calcular_paseo(View view){
        String cantidad;
        cantidad = etcantidad.getText().toString();
        if (cantidad.isEmpty()){
            Toast.makeText(this, "Digite la cantidad de personas", Toast.LENGTH_SHORT).show();
            etcantidad.requestFocus();
        }
        else {
            int cantidad_personas, valor_paseo;
            float valor_transporte = 0, valor_viaje, valor_sobrecosto;
            cantidad_personas = Integer.parseInt(cantidad);

            if (jrbpremiun.isChecked()) {
                valor_paseo = 495000;
                tvcategoria.setText("495000");
            } else if (jrbnormal.isChecked()){
                valor_paseo = 270000;
                tvcategoria.setText("270000");
            } else {
                valor_paseo = 140000;
                tvcategoria.setText("140000");
            }
            if (cbtransporte.isChecked()){
                valor_transporte = 30000 * cantidad_personas;
                tvtransporte.setText(String.valueOf(valor_transporte));
            } else {
                tvtransporte.setText("0");
                valor_transporte = 0;
            }

            if(cantidad_personas > 30) {
                valor_sobrecosto = (valor_paseo * cantidad_personas ) * 10/100;
                valor_viaje = (valor_paseo * cantidad_personas + valor_transporte) + valor_sobrecosto;
            } else {
                valor_viaje = valor_paseo * cantidad_personas + valor_transporte;
            }

            //String temporal = Format
            tvtotal.setText(String.valueOf(valor_viaje));
        }
    }
}